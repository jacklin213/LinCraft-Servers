package mffs;

import net.minecraft.server.EntityHuman;
import net.minecraft.server.IInventory;
import net.minecraft.server.ItemStack;
import net.minecraft.server.TileEntity;

public abstract class TileEntityMFFS extends TileEntity implements IInventory
{
    public int updateCount;
    public int baseUpdateCount;

    public void handleButton(int var1) {}

    public int[] getUpdate()
    {
        return null;
    }

    public void handleUpdate(int[] var1) {}

    public int[] getBaseUpdate()
    {
        return null;
    }

    public void handleBaseUpdate(int[] var1) {}

    /**
     * Returns the number of slots in the inventory.
     */
    public int getSize()
    {
        return 0;
    }

    /**
     * Returns the stack in slot i
     */
    public ItemStack getItem(int var1)
    {
        return null;
    }

    /**
     * Decrease the size of the stack in slot (first int arg) by the amount of the second int arg. Returns the new
     * stack.
     */
    public ItemStack splitStack(int var1, int var2)
    {
        return null;
    }

    /**
     * When some containers are closed they call this on each slot, then drop whatever it returns as an EntityItem -
     * like when you close a workbench GUI.
     */
    public ItemStack splitWithoutUpdate(int var1)
    {
        return null;
    }

    /**
     * Sets the given item stack to the specified slot in the inventory (can be crafting or armor sections).
     */
    public void setItem(int var1, ItemStack var2) {}

    /**
     * Returns the name of the inventory.
     */
    public String getName()
    {
        return "MFFS";
    }

    /**
     * Returns the maximum stack size for a inventory slot. Seems to always be 64, possibly will be extended. *Isn't
     * this more of a set than a get?*
     */
    public int getMaxStackSize()
    {
        return 64;
    }

    public void f() {}

    public void g() {}

    /**
     * Do not make give this method the name canInteractWith because it clashes with Container
     */
    public boolean a(EntityHuman var1)
    {
        return this.world.getTileEntity(this.x, this.y, this.z) == this && var1.e((double)this.x + 0.5D, (double)this.y + 0.5D, (double)this.z + 0.5D) <= 64.0D;
    }
}
