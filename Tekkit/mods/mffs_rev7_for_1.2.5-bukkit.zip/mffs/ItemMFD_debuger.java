package mffs;

import ic2.common.TileEntityNuclearReactor;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.ItemStack;
import net.minecraft.server.TileEntity;
import net.minecraft.server.World;

public class ItemMFD_debuger extends ItemMFD
{
    public ItemMFD_debuger(int var1)
    {
        super(var1, 3);
        this.d(3);
    }

    /**
     * Callback for item usage. If the item does something special on right clicking, he will have one of those. Return
     * True if something happen and false if it don't. This is for ITEMS, not BLOCKS !
     */
    public boolean interactWith(ItemStack var1, EntityHuman var2, World var3, int var4, int var5, int var6, int var7)
    {
        TileEntity var8 = var3.getTileEntity(var4, var5, var6);

        if (var8 instanceof TileEntityReaktorMonitorClient)
        {
            this.info.setLength(0);
            this.info.append("islink: ").append(((TileEntityReaktorMonitorClient)var8).isLinkMonitor());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("conectet_ID: ").append(((TileEntityReaktorMonitorClient)var8).getLinkMonitor_ID());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("status: ").append(((TileEntityReaktorMonitorClient)var8).getChannel());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("signal: ").append(((TileEntityReaktorMonitorClient)var8).isSignal());
            Functions.ChattoPlayer(var2, this.info.toString());
        }

        if (var8 instanceof TileEntityReaktorMonitor)
        {
            this.info.setLength(0);
            this.info.append("channel: ").append(((TileEntityReaktorMonitor)var8).getChannel(0));
            this.info.append(((TileEntityReaktorMonitor)var8).getChannel(1));
            this.info.append(((TileEntityReaktorMonitor)var8).getChannel(2));
            this.info.append(((TileEntityReaktorMonitor)var8).getChannel(3));
            this.info.append(((TileEntityReaktorMonitor)var8).getChannel(4));
            this.info.append(((TileEntityReaktorMonitor)var8).getChannel(5));
            Functions.ChattoPlayer(var2, this.info.toString());
        }

        if (var8 instanceof TileEntityReaktorCooler)
        {
            this.info.setLength(0);
            this.info.append("wrenchrate: ").append(((TileEntityReaktorCooler)var8).getWrenchDropRate());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("active: ").append(((TileEntityReaktorCooler)var8).getActive());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("isreaktor: ").append(((TileEntityReaktorCooler)var8).isIsreaktor());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("conectet_ID: ").append(((TileEntityReaktorCooler)var8).getconectet_ID());
            Functions.ChattoPlayer(var2, this.info.toString());
        }

        if (var8 instanceof TileEntityReaktorField)
        {
            this.info.setLength(0);
            this.info.append("reactorsize: ").append(((TileEntityReaktorField)var8).getReactorsize());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("isreaktor: ").append(((TileEntityReaktorField)var8).isIsreaktor());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.append("reactordist: ").append(((TileEntityReaktorField)var8).getReactordist());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.append("watercool: ").append(((TileEntityReaktorField)var8).isWatercool());
            Functions.ChattoPlayer(var2, this.info.toString());
        }

        if (var8 instanceof TileEntityReaktorConnector)
        {
            this.info.setLength(0);
            this.info.append("redpowert: ").append(((TileEntityReaktorConnector)var8).isredpowert());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("wrenchrate: ").append(((TileEntityReaktorConnector)var8).getWrenchDropRate());
            Functions.ChattoPlayer(var2, this.info.toString());
        }

        if (var8 instanceof TileEntityProjektor)
        {
            this.info.setLength(0);
            this.info.append("linkGenerator_ID: ").append(((TileEntityProjektor)var8).getLinkGenerator_ID());
            Functions.ChattoPlayer(var2, this.info.toString());
        }

        if (var8 instanceof TileEntityNuclearReactor)
        {
            this.info.setLength(0);
            this.info.append("Reaktor Hitze: ").append(((TileEntityNuclearReactor)var8).heat);
            Functions.ChattoPlayer(var2, this.info.toString());
        }

        if (var8 instanceof TileEntityGeneratorCore)
        {
            this.info.setLength(0);
            this.info.append("Generator ID: ").append(((TileEntityGeneratorCore)var8).getGenerator_ID());
            Functions.ChattoPlayer(var2, this.info.toString());
        }

        if (var8 instanceof TileEntityDirectionalExtender)
        {
            this.info.setLength(0);
            this.info.append("is create: ").append(((TileEntityDirectionalExtender)var8).isCreate());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("preactive: ").append(((TileEntityDirectionalExtender)var8).isPreactive());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("active: ").append(((TileEntityDirectionalExtender)var8).getActive());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("con_to_projektor: ").append(((TileEntityDirectionalExtender)var8).isCon_to_projektor());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("remProjektor_ID: ").append(((TileEntityDirectionalExtender)var8).getRemProjektor_ID());
            Functions.ChattoPlayer(var2, this.info.toString());
            this.info.setLength(0);
            this.info.append("remGenerator_ID: ").append(((TileEntityDirectionalExtender)var8).getRemGenerator_ID());
            Functions.ChattoPlayer(var2, this.info.toString());
            return true;
        }
        else
        {
            if (var3.getTypeId(var4, var5, var6) == mod_ModularForceFieldSystem.MFFSFieldblock.id)
            {
                FFBlock var9 = FFWorld.get(var3).get(var4, var5, var6);

                if (var9 != null)
                {
                    String[] var10 = var9.getDebugInfo().split("\n");
                    int var11 = var10.length;

                    for (int var12 = 0; var12 < var11; ++var12)
                    {
                        String var13 = var10[var12];
                        Functions.ChattoPlayer(var2, var13);
                    }

                    return true;
                }
            }

            return false;
        }
    }
}
