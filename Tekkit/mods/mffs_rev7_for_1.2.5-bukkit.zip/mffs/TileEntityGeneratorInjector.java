package mffs;

public class TileEntityGeneratorInjector extends TileEntityMaschines
{
    private boolean contocore = false;
    private int remGenerator_ID = 0;

    public boolean isContocore()
    {
        return this.contocore;
    }

    public void setContocore(boolean var1)
    {
        this.contocore = var1;
    }

    public int getRemGenerator_ID()
    {
        return this.remGenerator_ID;
    }

    public void setRemGenerator_ID(int var1)
    {
        this.remGenerator_ID = var1;
    }
}
