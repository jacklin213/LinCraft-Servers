package mffs;

import net.minecraft.server.ItemBlock;
import net.minecraft.server.ItemStack;

public class ItemUpgrades extends ItemBlock
{
    public ItemUpgrades(int var1)
    {
        super(var1);
        this.setMaxDurability(0);
        this.a(true);
    }

    /**
     * Returns the metadata of the block which this Item (ItemBlock) can place
     */
    public int filterData(int var1)
    {
        return this.getPlacedBlockMetadata(var1);
    }

    public int getPlacedBlockMetadata(int var1)
    {
        return var1;
    }

    public String a(ItemStack var1)
    {
        int var2 = var1.getData();

        switch (var2)
        {
            case 0:
                return "Reaktor_Monitor_Client";

            case 1:
                return "Projektor_Subwater";

            case 2:
                return "Projektor_Dome";

            case 3:
                return "Projektor_Hardner";

            case 4:
                return "Generator_Storage";

            case 5:
                return "Generator_Linkex";

            case 6:
                return "Projektor_Zapper";

            case 7:
                return "Projektor_camouflage";

            case 8:
                return "Reactor_Connector";

            default:
                return null;
        }
    }
}
