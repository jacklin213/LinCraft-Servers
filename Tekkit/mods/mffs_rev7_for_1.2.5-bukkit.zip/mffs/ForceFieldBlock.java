package mffs;

public class ForceFieldBlock
{
    private short mode;
    private int Projektor_ID;
    private int Generator_Id;
    private boolean freespace;
    private boolean active;

    public boolean isActive()
    {
        return this.active;
    }

    public void setActive(boolean var1)
    {
        this.active = var1;
    }

    public int getGenerator_Id()
    {
        return this.Generator_Id;
    }

    public void setFreespace(boolean var1)
    {
        this.freespace = var1;
    }

    public int getProjektor_ID()
    {
        return this.Projektor_ID;
    }

    public boolean isFreespace()
    {
        return this.freespace;
    }

    public short getMode()
    {
        return this.mode;
    }

    public ForceFieldBlock(int var1, int var2, boolean var3, boolean var4, short var5)
    {
        this.active = var4;
        this.freespace = var3;
        this.Projektor_ID = var2;
        this.Generator_Id = var1;
        this.mode = var5;
    }
}
